/**
 * LWATLE TECHNOLOGY SOLUTIONS - Main JavaScript
 * Modern Cybersecurity Website Interactions
 */

document.addEventListener('DOMContentLoaded', function() {
    
    // ============================================
    // PARTICLE BACKGROUND
    // ============================================
    const canvas = document.getElementById('particleCanvas');
    const ctx = canvas.getContext('2d');
    let particles = [];
    let animationId;
    let isActive = true;
    
    function resizeCanvas() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    class Particle {
        constructor() {
            this.x = Math.random() * canvas.width;
            this.y = Math.random() * canvas.height;
            this.size = Math.random() * 2 + 0.5;
            this.speedX = (Math.random() - 0.5) * 0.5;
            this.speedY = (Math.random() - 0.5) * 0.5;
            this.opacity = Math.random() * 0.5 + 0.1;
        }
        
        update() {
            this.x += this.speedX;
            this.y += this.speedY;
            
            if (this.x > canvas.width) this.x = 0;
            if (this.x < 0) this.x = canvas.width;
            if (this.y > canvas.height) this.y = 0;
            if (this.y < 0) this.y = canvas.height;
        }
        
        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
            ctx.fillStyle = `rgba(37, 99, 235, ${this.opacity})`;
            ctx.fill();
        }
    }
    
    function initParticles() {
        particles = [];
        const particleCount = window.innerWidth < 768 ? 30 : 60;
        for (let i = 0; i < particleCount; i++) {
            particles.push(new Particle());
        }
    }
    
    function connectParticles() {
        const maxDistance = 100;
        const maxConnections = 3;
        
        for (let i = 0; i < particles.length; i++) {
            let connections = 0;
            for (let j = i + 1; j < particles.length; j++) {
                const dx = particles[i].x - particles[j].x;
                const dy = particles[i].y - particles[j].y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < maxDistance && connections < maxConnections) {
                    ctx.beginPath();
                    ctx.strokeStyle = `rgba(37, 99, 235, ${0.1 * (1 - distance / maxDistance)})`;
                    ctx.lineWidth = 0.5;
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.stroke();
                    connections++;
                }
            }
        }
    }
    
    let frameCount = 0;
    function animateParticles() {
        if (!isActive) return;
        
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Render every 2nd frame for performance
        frameCount++;
        if (frameCount % 2 === 0) {
            particles.forEach(particle => {
                particle.update();
                particle.draw();
            });
            connectParticles();
        }
        
        animationId = requestAnimationFrame(animateParticles);
    }
    
    initParticles();
    animateParticles();
    
    // Pause animation when tab is hidden
    document.addEventListener('visibilitychange', () => {
        isActive = document.visibilityState === 'visible';
        if (isActive) {
            animateParticles();
        } else {
            cancelAnimationFrame(animationId);
        }
    });
    
    // ============================================
    // NAVIGATION
    // ============================================
    const nav = document.getElementById('nav');
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    
    // Scroll effect
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            nav.classList.add('scrolled');
        } else {
            nav.classList.remove('scrolled');
        }
    });
    
    // Mobile toggle
    navToggle.addEventListener('click', () => {
        navMenu.classList.toggle('active');
        const spans = navToggle.querySelectorAll('span');
        
        if (navMenu.classList.contains('active')) {
            spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
            spans[1].style.opacity = '0';
            spans[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
        } else {
            spans[0].style.transform = 'none';
            spans[1].style.opacity = '1';
            spans[2].style.transform = 'none';
        }
    });
    
    // Close menu on link click
    navMenu.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
            const spans = navToggle.querySelectorAll('span');
            spans[0].style.transform = 'none';
            spans[1].style.opacity = '1';
            spans[2].style.transform = 'none';
        });
    });
    
    // Active nav link
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');
    
    window.addEventListener('scroll', () => {
        let current = '';
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            if (scrollY >= sectionTop - 200) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === '#' + current) {
                link.classList.add('active');
            }
        });
    });
    
    // ============================================
    // COUNTER ANIMATION
    // ============================================
    const counters = document.querySelectorAll('.metric-value[data-count]');
    
    const counterObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const target = entry.target;
                const count = parseInt(target.getAttribute('data-count'));
                const suffix = target.nextElementSibling?.textContent || '';
                let current = 0;
                const increment = count / 50;
                const duration = 2000;
                const stepTime = duration / 50;
                
                const updateCounter = () => {
                    current += increment;
                    if (current < count) {
                        target.textContent = Math.floor(current);
                        setTimeout(updateCounter, stepTime);
                    } else {
                        target.textContent = count;
                    }
                };
                
                updateCounter();
                counterObserver.unobserve(target);
            }
        });
    }, { threshold: 0.5 });
    
    counters.forEach(counter => counterObserver.observe(counter));
    
    // ============================================
    // SERVICES TABS
    // ============================================
    const tabBtns = document.querySelectorAll('.tab-btn-v2');
    const servicePanels = document.querySelectorAll('.service-panel');
    
    tabBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            const serviceId = btn.getAttribute('data-service');
            
            tabBtns.forEach(b => b.classList.remove('active'));
            servicePanels.forEach(p => p.classList.remove('active'));
            
            btn.classList.add('active');
            document.getElementById(serviceId).classList.add('active');
        });
    });
    
    // ============================================
    // SCROLL REVEAL
    // ============================================
    const revealElements = document.querySelectorAll('.pillar-card, .factor-card-v2, .problem-card-v2, .scard, .sector-card, .traction-card');
    
    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                setTimeout(() => {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }, index * 100);
                revealObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });
    
    revealElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
        revealObserver.observe(el);
    });
    
    // ============================================
    // PROGRESS BAR ANIMATION
    // ============================================
    const progressBars = document.querySelectorAll('.tstat-fill');
    
    const progressObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const width = entry.target.style.getPropertyValue('--fill-width');
                entry.target.style.width = '0';
                setTimeout(() => {
                    entry.target.style.width = width;
                }, 200);
                progressObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });
    
    progressBars.forEach(bar => progressObserver.observe(bar));
    
    // ============================================
    // CONTACT FORM
    // ============================================
    const contactForm = document.getElementById('contactForm');
    const toast = document.getElementById('toast');
    
    contactForm.addEventListener('submit', (e) => {
        e.preventDefault();
        
        // Show toast
        toast.classList.add('show');
        
        // Reset form
        contactForm.reset();
        
        // Hide toast after 3 seconds
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    });
    
    // ============================================
    // SMOOTH SCROLL
    // ============================================
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                const offsetTop = target.offsetTop - 80;
                window.scrollTo({
                    top: offsetTop,
                    behavior: 'smooth'
                });
            }
        });
    });
    
    // ============================================
    // TERMINAL TYPING EFFECT
    // ============================================
    const terminalLines = document.querySelectorAll('.term-line');
    
    const terminalObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                terminalLines.forEach((line, index) => {
                    line.style.opacity = '0';
                    setTimeout(() => {
                        line.style.transition = 'opacity 0.3s ease';
                        line.style.opacity = '1';
                    }, index * 100);
                });
                terminalObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.3 });
    
    const terminal = document.querySelector('.terminal-v2');
    if (terminal) {
        terminalObserver.observe(terminal);
    }
    
    // ============================================
    // MISSION ITEMS ANIMATION
    // ============================================
    const missionItems = document.querySelectorAll('.mission-item');
    
    const missionObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                setTimeout(() => {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateX(0)';
                }, index * 200);
                missionObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.2 });
    
    missionItems.forEach(item => {
        item.style.opacity = '0';
        item.style.transform = 'translateX(-30px)';
        item.style.transition = 'all 0.5s ease';
        missionObserver.observe(item);
    });
    
    // ============================================
    // HOVER EFFECTS
    // ============================================
    const metricCards = document.querySelectorAll('.metric-card');
    
    metricCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            const icon = card.querySelector('.metric-icon');
            icon.style.transform = 'scale(1.1) rotate(-5deg)';
            icon.style.transition = 'transform 0.3s ease';
        });
        
        card.addEventListener('mouseleave', () => {
            const icon = card.querySelector('.metric-icon');
            icon.style.transform = 'scale(1) rotate(0)';
        });
    });
    
    // ============================================
    // PILLAR CARD HOVER
    // ============================================
    const pillarCards = document.querySelectorAll('.pillar-card');
    
    pillarCards.forEach(card => {
        const icon = card.querySelector('.pillar-icon');
        
        card.addEventListener('mouseenter', () => {
            icon.style.transform = 'scale(1.1) rotate(5deg)';
            icon.style.transition = 'transform 0.3s ease';
        });
        
        card.addEventListener('mouseleave', () => {
            icon.style.transform = 'scale(1) rotate(0)';
        });
    });
    
    // ============================================
    // FORM FIELD ANIMATIONS
    // ============================================
    const formFields = document.querySelectorAll('.form-field input, .form-field select, .form-field textarea');
    
    formFields.forEach(field => {
        field.addEventListener('focus', () => {
            field.parentElement.style.transform = 'translateX(5px)';
            field.parentElement.style.transition = 'transform 0.3s ease';
        });
        
        field.addEventListener('blur', () => {
            field.parentElement.style.transform = 'translateX(0)';
        });
    });
    
    // ============================================
    // CONTACT METHODS HOVER
    // ============================================
    const cmItems = document.querySelectorAll('.cm-item');
    
    cmItems.forEach(item => {
        item.addEventListener('mouseenter', () => {
            const icon = item.querySelector('.cm-icon');
            icon.style.background = 'var(--primary)';
            icon.style.color = 'white';
            icon.style.transform = 'scale(1.1)';
            icon.style.transition = 'all 0.3s ease';
        });
        
        item.addEventListener('mouseleave', () => {
            const icon = item.querySelector('.cm-icon');
            icon.style.background = 'rgba(37, 99, 235, 0.1)';
            icon.style.color = 'var(--primary)';
            icon.style.transform = 'scale(1)';
        });
    });
    
    // ============================================
    // TRACTION CARDS
    // ============================================
    const tractionCards = document.querySelectorAll('.traction-card');
    
    tractionCards.forEach(card => {
        card.addEventListener('mouseenter', () => {
            const icon = card.querySelector('.tc-icon');
            icon.style.animation = 'float 1s ease-in-out infinite';
        });
        
        card.addEventListener('mouseleave', () => {
            const icon = card.querySelector('.tc-icon');
            icon.style.animation = 'none';
        });
    });
    
    // ============================================
    // BUTTON RIPPLE EFFECT
    // ============================================
    const buttons = document.querySelectorAll('.btn');
    
    buttons.forEach(btn => {
        btn.addEventListener('click', function(e) {
            const rect = this.getBoundingClientRect();
            const x = e.clientX - rect.left;
            const y = e.clientY - rect.top;
            
            const ripple = document.createElement('span');
            ripple.style.cssText = `
                position: absolute;
                background: rgba(255, 255, 255, 0.3);
                border-radius: 50%;
                transform: scale(0);
                animation: ripple 0.6s linear;
                pointer-events: none;
                left: ${x}px;
                top: ${y}px;
                width: 100px;
                height: 100px;
                margin-left: -50px;
                margin-top: -50px;
            `;
            
            this.style.position = 'relative';
            this.style.overflow = 'hidden';
            this.appendChild(ripple);
            
            setTimeout(() => ripple.remove(), 600);
        });
    });
    
    // Add ripple keyframes
    const style = document.createElement('style');
    style.textContent = `
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
    `;
    document.head.appendChild(style);
    
    // ============================================
    // SCROLL INDICATOR HIDE
    // ============================================
    const scrollIndicator = document.querySelector('.hero-scroll');
    
    window.addEventListener('scroll', () => {
        if (window.scrollY > 100) {
            scrollIndicator.style.opacity = '0';
            scrollIndicator.style.transition = 'opacity 0.3s ease';
        } else {
            scrollIndicator.style.opacity = '1';
        }
    });
    
    // ============================================
    // NAV LINK MAGNETIC EFFECT
    // ============================================
    const navLinkElements = document.querySelectorAll('.nav-link');
    
    navLinkElements.forEach(link => {
        link.addEventListener('mousemove', (e) => {
            const rect = link.getBoundingClientRect();
            const x = e.clientX - rect.left - rect.width / 2;
            const y = e.clientY - rect.top - rect.height / 2;
            
            link.style.transform = `translate(${x * 0.1}px, ${y * 0.1}px)`;
        });
        
        link.addEventListener('mouseleave', () => {
            link.style.transform = 'translate(0, 0)';
        });
    });
    
    // ============================================
    // SECTION HEADERS ANIMATION
    // ============================================
    const sectionHeaders = document.querySelectorAll('.section-heading');
    
    const headerObserver = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
                headerObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.5 });
    
    sectionHeaders.forEach(header => {
        header.style.opacity = '0';
        header.style.transform = 'translateY(20px)';
        header.style.transition = 'all 0.6s ease';
        headerObserver.observe(header);
    });
    
    // ============================================
    // SH SOLUTION HIGHLIGHTS
    // ============================================
    const shItems = document.querySelectorAll('.sh-item');
    
    shItems.forEach(item => {
        item.addEventListener('mouseenter', () => {
            const icon = item.querySelector('i');
            icon.style.transform = 'rotate(360deg)';
            icon.style.transition = 'transform 0.5s ease';
        });
        
        item.addEventListener('mouseleave', () => {
            const icon = item.querySelector('i');
            icon.style.transform = 'rotate(0)';
        });
    });
    
    // ============================================
    // SECTOR CARD ICON ANIMATION
    // ============================================
    const sectorCards = document.querySelectorAll('.sector-card');
    
    sectorCards.forEach(card => {
        const icon = card.querySelector('.sector-icon');
        
        card.addEventListener('mouseenter', () => {
            icon.style.transform = 'scale(1.15) rotate(-10deg)';
            icon.style.transition = 'transform 0.3s ease';
        });
        
        card.addEventListener('mouseleave', () => {
            icon.style.transform = 'scale(1) rotate(0)';
        });
    });
    
    // ============================================
    // FACTOR CARD NUMBER ANIMATION
    // ============================================
    const factorCards = document.querySelectorAll('.factor-card-v2');
    
    factorCards.forEach(card => {
        const num = card.querySelector('.factor-num');
        
        card.addEventListener('mouseenter', () => {
            num.style.transform = 'scale(1.2) rotate(10deg)';
            num.style.transition = 'transform 0.3s ease';
        });
        
        card.addEventListener('mouseleave', () => {
            num.style.transform = 'scale(1) rotate(0)';
        });
    });
    
    // ============================================
    // CONSOLE LOG
    // ============================================
    console.log('%c🔒 LWATLE Technology Solutions', 'color: #2563EB; font-size: 20px; font-weight: bold;');
    console.log('%cCybersecurity for Africa\'s Digital Future', 'color: #64748B; font-size: 14px;');
    console.log('%cWebsite loaded successfully!', 'color: #10B981; font-size: 12px;');
});